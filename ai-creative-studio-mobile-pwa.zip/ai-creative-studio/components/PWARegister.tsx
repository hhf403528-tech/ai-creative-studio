'use client';
import { useEffect, useState } from 'react';
import { Download, X } from 'lucide-react';

type InstallPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> };

export default function PWARegister() {
  const [installPrompt, setInstallPrompt] = useState<InstallPrompt | null>(null);
  const [installed, setInstalled] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    const onPrompt = (event: Event) => { event.preventDefault(); setInstallPrompt(event as InstallPrompt); };
    const onInstalled = () => { setInstalled(true); setInstallPrompt(null); };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  if (!installPrompt || installed || dismissed) return null;
  const install = async () => {
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === 'accepted') setInstallPrompt(null);
  };
  return <aside className="install-card" aria-label="Install AI Creative Studio">
    <div className="install-symbol">✦</div>
    <div className="install-copy"><b>Install Creative Studio</b><span>Add it to your home screen for an app-like experience.</span></div>
    <button className="install-action" onClick={install}><Download size={15}/> Install</button>
    <button className="install-dismiss" aria-label="Dismiss install prompt" onClick={() => setDismissed(true)}><X size={17}/></button>
  </aside>;
}
