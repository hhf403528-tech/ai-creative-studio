import type { Metadata } from 'next';
import './globals.css';
import PWARegister from '@/components/PWARegister';
export const metadata: Metadata = { title: 'AI Creative Studio', description: 'Create images and animate them with AI.', applicationName: 'AI Creative Studio', appleWebApp: { capable: true, statusBarStyle: 'black-translucent', title: 'Creative Studio' }, icons: { icon: '/icons/icon-192.png', apple: '/icons/icon-192.png' }, manifest: '/manifest.webmanifest' };
export const viewport = { themeColor: '#0b0c10', width: 'device-width', initialScale: 1, viewportFit: 'cover' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}<PWARegister /></body></html>;
}
