import { NextRequest, NextResponse } from 'next/server';
export const runtime = 'nodejs';
const sizes: Record<string, [number, number]> = { '1:1':[1024,1024], '9:16':[768,1365], '16:9':[1365,768] };
export async function POST(req: NextRequest) {
  try {
    const { prompt, negativePrompt = '', aspectRatio = '1:1', seed } = await req.json();
    if (typeof prompt !== 'string' || prompt.trim().length < 3 || prompt.length > 1800) return NextResponse.json({ error: 'Enter a prompt between 3 and 1,800 characters.' }, { status: 400 });
    const apiKey = process.env.POLLINATIONS_API_KEY;
    if (!apiKey) return NextResponse.json({ error: 'Image generation is not configured yet. Add POLLINATIONS_API_KEY to your hosting environment and restart the app.' }, { status: 503 });
    const [width,height] = sizes[aspectRatio] ?? sizes['1:1'];
    const fullPrompt = negativePrompt ? `${prompt.trim()}. Avoid: ${negativePrompt.trim()}` : prompt.trim();
    const params = new URLSearchParams({ model: process.env.POLLINATIONS_IMAGE_MODEL || 'flux', width: String(width), height: String(height), nologo: 'true', private: 'true' });
    if (Number.isInteger(seed)) params.set('seed', String(seed));
    const url = `https://gen.pollinations.ai/image/${encodeURIComponent(fullPrompt)}?${params}`;
    const upstream = await fetch(url, { headers: { Authorization: `Bearer ${apiKey}` }, signal: AbortSignal.timeout(120000), cache: 'no-store' });
    if (!upstream.ok) {
      const detail = (await upstream.text()).slice(0, 500);
      return NextResponse.json({ error: `Image provider error (${upstream.status}): ${detail || 'Request failed'}` }, { status: 502 });
    }
    const type = upstream.headers.get('content-type') || 'image/jpeg';
    if (!type.startsWith('image/')) return NextResponse.json({ error: 'The provider returned an unexpected file type.' }, { status: 502 });
    const bytes = await upstream.arrayBuffer();
    if (bytes.byteLength > 15 * 1024 * 1024) return NextResponse.json({ error: 'Generated image is too large to return.' }, { status: 502 });
    return new NextResponse(bytes, { headers: { 'Content-Type': type, 'Cache-Control': 'no-store', 'Content-Disposition': 'inline' } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unexpected image generation error.' }, { status: 500 });
  }
}
