import { NextRequest, NextResponse } from 'next/server';
export const runtime = 'nodejs';
export const maxDuration = 300;
export async function POST(req: NextRequest) {
  try {
    const { prompt, image, duration = 5 } = await req.json();
    if (typeof prompt !== 'string' || prompt.trim().length < 3 || prompt.length > 1500) return NextResponse.json({ error: 'Enter a motion prompt between 3 and 1,500 characters.' }, { status: 400 });
    if (typeof image !== 'string' || !image.startsWith('data:image/')) return NextResponse.json({ error: 'Upload a starting image first.' }, { status: 400 });
    if (image.length > 12_000_000) return NextResponse.json({ error: 'Image is too large. Use an image under 8 MB.' }, { status: 413 });
    const apiKey = process.env.POLLINATIONS_API_KEY;
    if (!apiKey) return NextResponse.json({ error: 'Video generation is not configured yet. Add POLLINATIONS_API_KEY to your hosting environment.' }, { status: 503 });
    // The provider accepts an image-guided video request. Provider/model support and limits may change.
    const model = process.env.POLLINATIONS_VIDEO_MODEL || 'wan';
    const endpoint = `https://gen.pollinations.ai/video/${encodeURIComponent(prompt.trim())}`;
    const upstream = await fetch(endpoint, { method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model, image: [image], duration: Math.min(8, Math.max(3, Number(duration) || 5)) }), signal: AbortSignal.timeout(290000), cache: 'no-store' });
    if (!upstream.ok) {
      const detail = (await upstream.text()).slice(0, 700);
      return NextResponse.json({ error: `Video provider error (${upstream.status}): ${detail || 'Request failed'}. Check the current video model catalog and image-input support.` }, { status: 502 });
    }
    const type = upstream.headers.get('content-type') || '';
    if (type.startsWith('video/')) return new NextResponse(await upstream.arrayBuffer(), { headers: { 'Content-Type': type, 'Cache-Control': 'no-store' } });
    const payload = await upstream.json().catch(() => null) as { data?: Array<{ url?: string; b64_json?: string }> } | null;
    const item = payload?.data?.[0];
    if (item?.url) return NextResponse.json({ url: item.url });
    if (item?.b64_json) return NextResponse.json({ url: `data:video/mp4;base64,${item.b64_json}` });
    return NextResponse.json({ error: 'The provider response did not contain a playable video.' }, { status: 502 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unexpected video generation error.' }, { status: 500 });
  }
}
