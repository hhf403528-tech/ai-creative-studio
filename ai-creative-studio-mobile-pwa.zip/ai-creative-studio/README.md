# AI Creative Studio — MVP

A responsive Next.js starter for a cloud-first AI image and image-to-video studio. The UI and API routes are included; generation is performed server-side so provider secrets are not exposed in browser code.

## Important about “free”

The application code is free/open-source, but cloud inference is not guaranteed to be free or unlimited. Pollinations currently offers a unified media API and a changing model catalog. You may need an API key, account balance, or to follow provider limits. Check the live catalog and pricing before opening this to the public. Never promise unlimited free generations.

## Run locally

1. Install Node.js 20.9+.
2. Copy `.env.example` to `.env.local`.
3. Add a Pollinations API key from https://enter.pollinations.ai/ to `POLLINATIONS_API_KEY`.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open http://localhost:3000.

Image generation calls `https://gen.pollinations.ai/image/{prompt}` from the server. The default image model is `flux`; set `POLLINATIONS_IMAGE_MODEL` to a currently supported model ID if needed.

Image-to-video calls the provider's video endpoint with the uploaded image and motion prompt. Video model IDs and accepted image input formats change; set `POLLINATIONS_VIDEO_MODEL` to a currently supported image-conditioned video model from https://gen.pollinations.ai/video/models or the live model catalog. If the selected provider does not accept inline data URLs, the route must be adapted to upload the image to a provider-supported media URL first. Video generation is synchronous and may take several minutes.

## Enable accounts

1. Create a Supabase project.
2. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in `.env.local`.
3. Enable Email auth in Supabase Authentication settings.
4. Restart the app.

The sign-in/sign-up UI uses Supabase Auth. In this MVP, creations are saved in browser local storage (per browser/device), not synced to the cloud account. Before production, move history and media to a storage bucket with per-user access policies.

## Deploy

Deploy the Next.js project to a host that supports server-side route handlers and sufficiently long request timeouts. Add the same environment variables in the host dashboard. Image generation can take up to 120 seconds; video can take up to 290 seconds. Many free serverless plans have shorter execution limits, so video generation may require a long-running host or a queued job worker. For production, implement authentication checks, per-user quotas, rate limiting, moderation, job queues, and storage lifecycle policies before making the API public.

## Security and production checklist

- Keep `POLLINATIONS_API_KEY` server-only. Never prefix it with `NEXT_PUBLIC_`.
- Add auth checks to both generation endpoints before public launch.
- Add rate limits and per-account quotas to prevent abuse and unexpected inference costs.
- Add prompt/content moderation and provider terms compliance.
- Use object storage for outputs and signed URLs; don't persist base64 media in a database.
- Implement asynchronous job status for video if your hosting provider cannot hold a request open.
- Review privacy, retention, and copyright policies before accepting public users.

## Project layout

- `app/page.tsx` — studio page
- `components/Studio.tsx` — responsive UI and client interactions
- `app/api/generate/image/route.ts` — server-side image generation proxy
- `app/api/generate/video/route.ts` — server-side image-to-video proxy
- `lib/supabase.ts` — optional Supabase client
- `supabase/schema.sql` — optional profile table with row-level security

## Install on Android (PWA)

The project includes a web app manifest, app icons, a lightweight service worker, and an install prompt. Deploy the site over HTTPS, then open it in Chrome on Android. Use the browser's **Install app** / **Add to Home screen** option (or the in-app Install prompt when Chrome exposes it). The PWA shell provides an offline fallback page; image/video generation still requires an internet connection. For iPhone, use Safari's Share menu and choose **Add to Home Screen**.

The same responsive website is the first deliverable. A native Android wrapper can be added later (for example with Capacitor) after the web app and generation APIs are stable.
