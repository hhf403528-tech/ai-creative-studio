import Cart3r from '@/components/Cart3r';
import './cart3r.css';
export const metadata = { title: 'CART3R.JAILBREAK — Developer Command Center' };
export default function Cart3rPage(){ return <Cart3r/>; }
