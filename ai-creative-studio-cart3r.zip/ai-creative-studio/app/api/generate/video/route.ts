import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const maxDuration = 300;

const BASE = 'https://apihub.agnes-ai.com';
const MODEL = 'agnes-video-2.5-flash';

export async function POST(req: NextRequest) {
  try {
    const { prompt, image, duration = 5 } = await req.json();
    const apiKey = process.env.AGNES_API_KEY;

    if (!apiKey) {
      return NextResponse.json(
        { error: 'AGNES_API_KEY is missing.' },
        { status: 503 }
      );
    }

    if (typeof prompt !== 'string' || prompt.trim().length < 3 || prompt.length > 1500) {
      return NextResponse.json(
        { error: 'Enter a motion prompt between 3 and 1500 characters.' },
        { status: 400 }
      );
    }

    if (typeof image !== 'string' || !image.startsWith('data:image/')) {
      return NextResponse.json(
        { error: 'Upload a starting image first.' },
        { status: 400 }
      );
    }

    if (image.length > 12000000) {
      return NextResponse.json(
        { error: 'Image is too large. Use an image under 8 MB.' },
        { status: 413 }
      );
    }

    const seconds = String(Math.min(12, Math.max(4, Math.round(Number(duration) || 5))));

    const requestBody = JSON.stringify({
    model: MODEL,
    prompt: prompt.trim(),
    mode: 'keyframe',
    first_frame: image,
    seconds,
    size: '720P',
    aspect_ratio: '9:16',
    n: 1
  });

  let upstream: Response | null = null;
  let created: any = null;

  for (let attempt = 1; attempt <= 4; attempt++) {
    upstream = await fetch(`${BASE}/v1/videos`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: requestBody,
      signal: AbortSignal.timeout(60000),
      cache: 'no-store'
    });

    created = await upstream.json().catch(() => null);

    const queueFull =
      upstream.status === 503 &&
      created?.code === 'video_queue_full';

    if (!queueFull || attempt === 4) break;

    console.log(`Agnes queue full. Retry ${attempt}/3 in 15 seconds.`);
    await new Promise(resolve => setTimeout(resolve, 15000));
  }

  if (!upstream || !upstream.ok) {
    const message = created?.message || created?.error || 'Request failed';

    return NextResponse.json(
      { error: `Agnes error (${upstream?.status || 502}): ${message}` },
      { status: upstream?.status === 503 ? 503 : 502 }
    );
  }

  const videoId = created?.video_id;

    if (!videoId) {
      return NextResponse.json(
        { error: 'Agnes did not return a video ID.' },
        { status: 502 }
      );
    }

    for (let i = 0; i < 34; i++) {
      await new Promise(resolve => setTimeout(resolve, 7000));

      const statusResponse = await fetch(
        `${BASE}/agnesapi?video_id=${encodeURIComponent(videoId)}&model_name=${MODEL}`,
        {
          headers: { Authorization: `Bearer ${apiKey}` },
          signal: AbortSignal.timeout(25000),
          cache: 'no-store'
        }
      );

      const status = await statusResponse.json().catch(() => null);

      if (!statusResponse.ok) {
        return NextResponse.json(
          { error: 'Could not check Agnes video status.' },
          { status: 502 }
        );
      }

      if (status?.status === 'failed') {
        return NextResponse.json(
          { error: status.error || 'Video generation failed.' },
          { status: 502 }
        );
      }

      if (status?.status === 'completed') {
        const url = status.url || status.video_url;

        if (url) return NextResponse.json({ url });
      }
    }

    return NextResponse.json(
      { error: 'Video is still processing. Please try again later.' },
      { status: 504 }
    );

  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unexpected video generation error.' },
      { status: 500 }
    );
  }
}
