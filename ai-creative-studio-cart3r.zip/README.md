# AI Creative Studio + CART3R.JAILBREAK

Mobile-first Next.js creative workspace with an integrated CART3R developer command center.

## Zero-budget policy

- Agnes video requests are hard-locked to `agnes-video-2.5-flash`; there is no paid-model or alternate-provider fallback.
- Provider promotions and free quotas can change. Confirm that your own Agnes account shows $0 access and does not require a card before generating. Do not enable billing or add a payment method.
- Video duration is 4–12 whole seconds, with 10 seconds selected by default.
- Image generation is blocked unless `POLLINATIONS_FREE_CONFIRMED=true`. Keep it `false` unless you independently verify genuine $0 access without a card. No request is sent while the lock is off.
- If free access is unavailable or exhausted, stop. Never fall back to a paid service.

## CART3R command center

Open `/cart3r` from the studio sidebar. It includes an overview, searchable command directory, code lab, developer task briefs, security center, terms, settings, and about page. It is a local reference/editor interface; it does not remotely control Codespaces or execute code.

## Run in GitHub Codespaces

1. Keep the real Agnes key in `.env.local` as `AGNES_API_KEY=...`. Never share it in chat or commit it.
2. Keep `POLLINATIONS_FREE_CONFIRMED=false` unless its current free/no-card terms are verified.
3. Run `npm install` if dependencies are not installed.
4. Run `npm run dev -- --hostname 0.0.0.0` and open forwarded port 3000.

## Project map

- `app/page.tsx` — creative studio
- `components/Studio.tsx` — creative workspace UI
- `app/api/generate/video/route.ts` — Agnes image-to-video proxy
- `app/api/generate/image/route.ts` — Pollinations route with zero-budget lock
- `app/cart3r/page.tsx` — CART3R developer center
- `components/Cart3r.tsx` — command center interactions
- `app/cart3r/cart3r.css` — CART3R black/crimson responsive theme
- `lib/supabase.ts` — optional Supabase client

## Security

This package intentionally excludes `.env.local`, provider keys, and private credentials. Do not upload those files when sharing a project archive.
